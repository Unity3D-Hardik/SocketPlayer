﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum PowerOnOffLogoEnum
    {
        PLPowerOnLogo=0,
        PLPowerOnAnimation=1,
        PLPowerOffAnimation=2
    }
}