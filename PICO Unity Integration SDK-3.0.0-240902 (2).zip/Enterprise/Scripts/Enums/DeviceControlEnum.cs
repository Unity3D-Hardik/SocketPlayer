﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum DeviceControlEnum
    {
        DEVICE_CONTROL_REBOOT=0,
        DEVICE_CONTROL_SHUTDOWN=1
    }
}